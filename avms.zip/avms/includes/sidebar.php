<aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
        
                   <h1>AVMS</h1>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li>
                            <a href="dashboard.php"  style="color: blue">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

     <li>
                            <a href="visitors-form.php"  style="color: blue">
                                <i class="fa fa-user"></i>New Visitor</a>
                        </li>
   <li>
                            <a href="manage-newvisitors.php"  style="color: blue">
                                <i class="fa fa-users"></i>Manage Visitors</a>
                        </li>

                        
                      <li>
                            <a href="bwdates-reports.php"  style="color: blue">
                                <i class="fas fa-copy"></i>Vistors B/w Dates</a>
                        </li>  
                       
                    </ul>
                </nav>
            </div>
        </aside>